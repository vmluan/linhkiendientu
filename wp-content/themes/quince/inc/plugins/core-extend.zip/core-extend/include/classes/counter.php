<?php

class WPBakeryShortCode_VC_Counter extends WPBakeryShortCode {

}